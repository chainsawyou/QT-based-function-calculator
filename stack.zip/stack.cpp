#include "stack.h"
#include "ui_stack.h"
#include "form1.h"
#include "ui_form1.h"
#include "form2.h"
#include "ui_form2.h"
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "ui_form1.h"
#include "form1.h"
#include "client.h"
#include "ui_client.h"
#include <QDebug>
#include <QPushButton>
#include <QStackedWidget>
#include <QGridLayout>


QStackedWidget *pStack;

stack::stack(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::stack)
{
        ui->setupUi(this);
        setWindowTitle(tr("StackedWidget"));
        setMinimumSize(800, 400);
        qDebug("Hello");

        QPushButton *pButton1 = new QPushButton("计\n算\n时\n间", this);
        QPushButton *pButton2 = new QPushButton("三\n角\n函\n数", this);
        QPushButton *pButton3 = new QPushButton("简\n单\n运\n算", this);
        QPushButton *pButton4 = new QPushButton("解\n答\n？");
        pButton3->setFixedSize(QSize(44,90));
        pButton3->setFont(QFont("Times", 10));
        pButton1->setFixedSize(QSize(44,90));
        pButton1->setFont(QFont("Times", 10));
        pButton2->setFixedSize(QSize(44,90));
        pButton2->setFont(QFont("Times", 10));
        pButton4->setFixedSize(QSize(44,90));
        pButton4->setFont(QFont("Times", 10));

        pStack = new QStackedWidget(this);
        MainWindow *pC1Widget = new MainWindow();
        Form1 *pC3Widget = new Form1();
        Form2 *pC2Widget = new Form2();
        client *pC4Widget = new client();
        pStack->addWidget(pC1Widget);
        pStack->addWidget(pC2Widget);
        pStack->addWidget(pC3Widget);
        pStack->addWidget(pC4Widget);

        QGridLayout *mainLayout = new QGridLayout(this);
        mainLayout->addWidget(pButton1, 0, 0, Qt::AlignCenter);
        mainLayout->addWidget(pButton2, 1, 0, Qt::AlignCenter);
        mainLayout->addWidget(pButton3, 2, 0, Qt::AlignCenter);
        mainLayout->addWidget(pButton4, 3, 0, Qt::AlignCenter);
        mainLayout->addWidget(pStack, 0, 1, 4, 1);

        mainLayout->setContentsMargins(10,10,1,1);
        mainLayout->setColumnStretch(1, 10);
        mainLayout->setRowStretch(1, 1);

        connect(pButton1, SIGNAL(clicked()), this, SLOT(showForm1()));
        connect(pButton2, SIGNAL(clicked()), this, SLOT(showForm2()));
        connect(pButton3, SIGNAL(clicked()), this, SLOT(showForm3()));
        connect(pButton4, SIGNAL(clicked()), this, SLOT(showForm4()));
}

void stack::showForm1()
{
    qDebug("%s", __func__);
    pStack->setCurrentIndex(0);
}
void stack::showForm2()
{
    qDebug("%s", __func__);
    pStack->setCurrentIndex(1);
}
void stack::showForm3()
{
    qDebug("%s", __func__);
    pStack->setCurrentIndex(2);
}

void stack::showForm4()
{
//    qDebug("%s", __func__);
//    pStack->setCurrentIndex(3);
    client *i=new client;
    i->show();
}


stack::~stack()
{
    delete ui;
}
