#include "stack.h"
#include <QApplication>
#include "form1.h"
#include "form2.h"
#include <string.h>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    stack w;
    w.show();

    return a.exec();
}
