#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<QMessageBox>
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
        timeSet=ui->timeEdit->time();  //设置初始时间
        ui->lineEdit->setText(timeSet.toString());
        hasSetTime=false;
        btnStartHasClick=false;
        isStop=false;
         QTimer *timer = new QTimer(this);   //初始化定义
         connect(timer,SIGNAL(timeout()),this,SLOT(update()));
         timer->start(1000);

}
MainWindow::~MainWindow()
{
    delete ui;
}
void MainWindow::on_timeEdit_userTimeChanged(const QTime &time)
{
    ui->lineEdit->setText(time.toString());
        setSecond=time.hour()*3600+time.minute()*60;//储存设置的时间
        hasSetTime=true;
        btnStartHasClick=false;
}
void MainWindow::paintEvent(QPaintEvent *event){
    QPainter painter(this); //画家
    QPen pen(QColor(Qt::black));
    QBrush brush(QColor(Qt::white));//画刷
    pen.setWidth(1);   //笔大小
    painter.setPen(pen); //画家拿笔和刷子
    painter.setBrush(brush);
    //把中心点移到0 0 因为旋转是要围绕坐标(0,0)旋转
    painter.translate(width()/2, height()/2);
    painter.drawEllipse(QPoint(0,5),125,125);  //半径160px的圆
    painter.drawPoint(0,0);     //中心点
    painter.drawLine(0,-160,0,-140); //画刻度
    int line_h;
    for(int i=1; i<=60; i++){
        line_h = -150;  //短刻度
        painter.save();
        painter.rotate(i*6);
        if(i % 5 == 0){
            line_h = -140;  //长刻度
            painter.drawText(-5,-125,tr("%1").arg(i/5)); //画 文本
        }
        painter.drawLine(0,-160,0,line_h);
        painter.restore();
    }
    QTime time = QTime::currentTime();//获取时间 /
    //画秒针
    painter.save();     //先保存之前的操作
    painter.rotate(6.0*time.second());
    pen.setWidth(2);    //设置笔粗细
    painter.setPen(pen);    //画家再次拿笔
    painter.drawLine(0,0,0,-100);   //(0,0)开始 到坐标(0,100)
    painter.restore();  //恢复
    //画 分针
    painter.save();
    painter.rotate(6.0*time.minute()+6.0*time.second()/60);
    pen.setWidth(4);
    painter.setPen(pen);
    painter.drawLine(0,0,0,-80);
    painter.restore();
    //画 时针
    painter.save();
    painter.rotate(30*time.hour()+6.0*time.minute()/60);
    pen.setWidth(6);
    painter.setPen(pen);
    painter.drawLine(0,0,0,-40);
    painter.restore();
}
void MainWindow::on_btnStart_clicked()
{
    isStop=false;
       if(btnStartHasClick){

       }
       else
       {
           if(hasSetTime)
           {
               timerId=startTimer(1000);//计时开始,每秒调用一次timerEvent函数，并获得这个定时器的Id
               btnStartHasClick=true;
           }
           else
           {
               QMessageBox::information(this,"提示","先设置时间");
           }

       }

}
void MainWindow::timerEvent(QTimerEvent *)
{
    if(isStop){}
    else
    {
        setSecond-=1;
        //设置显示屏时间
        timeSet.setHMS(setSecond/3600,(setSecond-setSecond/3600*3600)/60,setSecond-setSecond/60*60);
        ui->lineEdit->setText(timeSet.toString());

        if(setSecond==0)
        {

            QMessageBox::information(this,"提示","时间到");
            killTimer(timerId);//时间到,关闭计时器
        }
    }
}
void MainWindow::on_btnStop_clicked()
{
    if(btnStartHasClick)
        {
            isStop=true;
        }
        else
        {
            QMessageBox::information(this,"提示","未开始计时");
        }
}

void MainWindow::on_btnReset_clicked()
{
    if(btnStartHasClick){
            killTimer(timerId);//关闭计时器
            timeSet.setHMS(0,0,0);  //重置显示屏
            ui->lineEdit->setText(timeSet.toString());
            QTime time(0,0,0); //重置timeEdit时间
            ui->timeEdit->setTime(time);
            hasSetTime=false;
            btnStartHasClick=false;
        }
        else
        {
            QMessageBox::information(this,"提示","未开始计时");
        }
}
