#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include<QTime>
#include<QLineEdit>
#include<QTimerEvent>
#include <QPaintEvent>	//绘图事件
#include <QDebug>		//测试
#include <QPainter>	//画家
#include <QPen>	//笔
#include <QBrush>	//画刷
#include <QPoint>	//点
#include <QTimer>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:

    void on_timeEdit_userTimeChanged(const QTime &time);

    void on_btnStart_clicked();

    void on_btnStop_clicked();

    void on_btnReset_clicked();

protected:
    void timerEvent(QTimerEvent *);
    void paintEvent(QPaintEvent *event);

private:
    Ui::MainWindow *ui;
    QTime timeSet;
        QLineEdit lineEditGet;
        int setSecond;
        int timerId;
        bool hasSetTime;
        bool btnStartHasClick;
        bool isStop;
};

#endif // MAINWINDOW_H
