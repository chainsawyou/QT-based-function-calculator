#ifndef STACK_H
#define STACK_H

#include <QWidget>
#include <QStackedWidget>


namespace Ui {
class stack;
}

class stack : public QWidget
{
    Q_OBJECT

public:
    explicit stack(QWidget *parent = 0);
    ~stack();

private slots:
    void showForm1();
    void showForm2();
    void showForm3();
    void showForm4();

private:
    Ui::stack *ui;
};

#endif // STACK_H
