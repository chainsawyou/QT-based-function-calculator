#ifndef FORM1_H
#define FORM1_H

#include <QWidget>
#include <QStack>//利用STL容器栈
#include <string.h>
#include <QByteArray>

namespace Ui {
class Form1;
}

class Form1 : public QWidget
{
    Q_OBJECT

public:
    explicit Form1(QWidget *parent = 0);
    ~Form1();

private slots:
    void on_one_clicked();


    void on_two_clicked();

    void on_three_clicked();

    void on_five_clicked();

    void on_four_clicked();

    void on_six_clicked();

    void on_seven_clicked();

    void on_eight_clicked();

    void on_nine_clicked();

    void on_zero_clicked();

    void on_left_clicked();

    void on_chen_clicked();

    void on_chu_clicked();

    void on_right_clicked();

    void on_clear_clicked();

    void on_move_clicked();

    void on_jia_clicked();

    void on_jian_clicked();

    void on_equal_clicked();

private:
    Ui::Form1 *ui;
    QString text; //计算器文本框输出内容

    int Priority(char ch);//获取运算符优先级

};

#endif // FORM1_H
