#ifndef FORM2_H
#define FORM2_H

#include <QWidget>

#include <QStackedWidget>

namespace Ui {
class Form2;
}

class Form2 : public QWidget
{
    Q_OBJECT

public:
    explicit Form2(QWidget *parent = 0);
    ~Form2();
    void onLineEdit();

private slots:
    void FunctionPressed();
    void NumPressed();
    void ClearText();
    void DotBtnPressed();
    void CloseBtnPressed();
    void ChangeNumberSign();
    void on_Rad_clicked();
    void on_Inv_clicked();

private:
    Ui::Form2 *ui;
};

#endif // FORM2_H
