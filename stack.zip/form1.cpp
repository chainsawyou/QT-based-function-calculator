#include "form1.h"
#include "ui_form1.h"
#include "form2.h"
#include <QApplication>

Form1::Form1(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Form1)
{
    ui->setupUi(this);

    //设置窗口名称
    this->setWindowTitle("实现基本四则运算的简易计算器");

    //设置窗口大小
    this->setMaximumSize(710,490);
    this->setMinimumSize(710,490);

    //设置字体
    QFont f("黑体",20);
    ui->lineEdit->setFont(f);

    //改变按钮背景颜色
    ui->equal->setStyleSheet("background:light green");
    ui->clear->setStyleSheet("background:light red");
    ui->move->setStyleSheet("background:light yellow");

    ui->jia->setStyleSheet("background:grey");
    ui->jian->setStyleSheet("background:grey");
    ui->chen->setStyleSheet("background:grey");
    ui->chu->setStyleSheet("background:grey");
    ui->right->setStyleSheet("background:grey");
    ui->left->setStyleSheet("background:grey");

    ui->zero->setStyleSheet("background:light pink");
    ui->one->setStyleSheet("background:light pink");
    ui->two->setStyleSheet("background:light pink");
    ui->three->setStyleSheet("background:light pink");
    ui->four->setStyleSheet("background:light pink");
    ui->five->setStyleSheet("background:light pink");
    ui->six->setStyleSheet("background:light pink");
    ui->seven->setStyleSheet("background:light pink");
    ui->eight->setStyleSheet("background:light pink");
    ui->nine->setStyleSheet("background:light pink");

//    //在按钮上放图片
//    QIcon con("路径");//注意用"\\"转义字符
//    ui->zero->setIcon(con);

}

Form1::~Form1()
{
    delete ui;
}


void Form1::on_one_clicked()
{
    text += "1";
    ui->lineEdit->setText(text);
}


void Form1::on_two_clicked()
{
    text += "2";
    ui->lineEdit->setText(text);
}


void Form1::on_three_clicked()
{
    text += "3";
    ui->lineEdit->setText(text);
}


void Form1::on_five_clicked()
{
    text += "4";
    ui->lineEdit->setText(text);
}


void Form1::on_four_clicked()
{
    text += "5";
    ui->lineEdit->setText(text);
}


void Form1::on_six_clicked()
{
    text += "6";
    ui->lineEdit->setText(text);
}


void Form1::on_seven_clicked()
{
    text += "7";
    ui->lineEdit->setText(text);
}


void Form1::on_eight_clicked()
{
    text += "8";
    ui->lineEdit->setText(text);
}


void Form1::on_nine_clicked()
{
    text += "9";
    ui->lineEdit->setText(text);
}


void Form1::on_zero_clicked()
{
    text += "0";
    ui->lineEdit->setText(text);
}


void Form1::on_left_clicked()
{
    text += "(";
    ui->lineEdit->setText(text);
}


void Form1::on_jia_clicked()
{
    text += "+";
    ui->lineEdit->setText(text);
}


void Form1::on_jian_clicked()
{
    text += "-";
    ui->lineEdit->setText(text);
}


void Form1::on_chen_clicked()
{
    text += "×";
    ui->lineEdit->setText(text);
}


void Form1::on_chu_clicked()
{
    text += "÷";
    ui->lineEdit->setText(text);
}


void Form1::on_right_clicked()
{
    text += ")";
    ui->lineEdit->setText(text);
}


//清除文本框内容
void Form1::on_clear_clicked()
{
    text.clear();//clear是对象函数而不是指针
    ui->lineEdit->clear();
}


//删除文本框最后一个字符
void Form1::on_move_clicked()
{
    text.chop(1);
    ui->lineEdit->setText(text);//显示删除后的内容
}


void Form1::on_equal_clicked()
{
    QStack<int> s_num, s_opt;//栈中存储输入的数据及运算符

    char opt[128] = {0};
    int i = 0, tmp = 0, num1, num2, num;

    //把QString转换成char *
    QByteArray arr; //数组类
    arr = text.toLatin1();   //把QString转换成QByteArray，存入数组arr
    strcpy(opt, arr.data());  //data可以把QByteArray转换成const char *字符串存入数组

    while (opt[i] != '\0' || s_opt.empty() != true)
    {
        if (opt[i] >= '0' && opt[i] <= '9')
        {
            tmp = tmp * 10 + opt[i] - '0';
            i++;
            if (opt[i] < '0' || opt[i] > '9')
            {
                s_num.push(tmp);
                tmp = 0;
            }
        }

        //操作符
        else
        {
            if (s_opt.empty() == true || Priority(opt[i]) > Priority(s_opt.top()) ||
                    (s_opt.top() == '(' && opt[i] != ')'))
            {
                s_opt.push(opt[i]);//(之后的元素即)之前的元素入栈，继续读取下一个元素
                i++;
                continue;
            }

            if (s_opt.top() == '(' && opt[i] == ')')
            {
                s_opt.pop();//括号内的元素读取完毕，出栈继续读取)后的元素
                i++;
                continue;
            }

            if (Priority(opt[i]) <= Priority(s_opt.top()) || (opt[i] == ')' && s_opt.top() != '(') ||
                (opt[i] == '\0' && s_opt.empty() != true))//栈中元素读取完毕或进行高优先级算术运算
            {
                char ch = s_opt.top();
                s_opt.pop();
                switch(ch)
                {
                    case '+':
                        num1 = s_num.top();//读取栈顶元素后再出栈
                        s_num.pop();
                        num2 = s_num.top();
                        s_num.pop();
                        s_num.push(num1 + num2);
                        break;
                    case '-':
                        num1 = s_num.top();
                        s_num.pop();//先出栈在后台属于第一个数
                        num2 = s_num.top();
                        s_num.pop();
                        s_num.push(num2 - num1);//应颠倒运算顺序
                        break;
                    case '*':
                        num1 = s_num.top();
                        s_num.pop();
                        num2 = s_num.top();
                        s_num.pop();
                        s_num.push(num1 * num2);
                        break;
                    case '/':
                        num1 = s_num.top();
                        s_num.pop();
                        num2 = s_num.top();
                        s_num.pop();
                        s_num.push(num2 / num1);
                        break;
                }
            }
        }
    }
    //计算结果显示完成后需要出栈然后被清除 以便进行下一次运算
    ui->lineEdit->setText(QString::number(s_num.top()));//QString里的number成员函数将int型的num转化为字符串输出
    text.clear();
}


//判断操作符优先级
int Form1::Priority(char ch)
{
    switch(ch)
    {
        case '(':
            return 3;
        case '*':
        case '/':
            return 2;
        case '+':
        case '-':
            return 1;
        default:
            return 0;
    }
}

