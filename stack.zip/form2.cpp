#include "form2.h"
#include "ui_form2.h"
#include <QString>
#include <cmath>
#include <QPushButton>
#include <QRegExp>
#include <QDebug>
#include <QMessageBox>
#include <QtMath>

double calcVal = 0.0;
double PI = 3.14159265358979323846;

Form2::Form2(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Form2)
{
    ui->setupUi(this);

    ui->InputText->setText(QString::number(calcVal));

    QPushButton *numButtons[10];
    for(int i = 0; i < 10 ; ++i)
    {
        QString butName = "Button" + QString::number(i);
        numButtons[i] = Form2::findChild<QPushButton *>(butName);
        connect(numButtons[i],SIGNAL(released()),this,SLOT(NumPressed()));
    }

    connect(ui->Sin, SIGNAL(released()), this,
                SLOT(FunctionPressed()));
    connect(ui->Cos, SIGNAL(released()), this,
                SLOT(FunctionPressed()));
    connect(ui->Tan, SIGNAL(released()), this,
                SLOT(FunctionPressed()));
    connect(ui->Sec, SIGNAL(released()), this,
                SLOT(FunctionPressed()));
    connect(ui->Csc, SIGNAL(released()), this,
                SLOT(FunctionPressed()));
    connect(ui->Cot, SIGNAL(released()), this,
                SLOT(FunctionPressed()));
    connect(ui->Clear,SIGNAL(released()),this,
                SLOT(ClearText()));
    connect(ui->Dot,SIGNAL(released()),this,
                   SLOT(DotBtnPressed()));
    connect(ui->Close,SIGNAL(released()),this,
                   SLOT(CloseBtnPressed()));
    connect(ui->ChangeSign, SIGNAL(released()), this,
                   SLOT(ChangeNumberSign()));

       //connect(ui->InputText, &QLineEdit::editingFinished, this, &DRtFunc::onLineEdit);

}

Form2::~Form2()
{
    delete ui;
}

void Form2::ChangeNumberSign()
{

    QString displayVal = ui->InputText->text();

    QRegExp reg("[-+]?[0-9.]*");

    if(reg.exactMatch(displayVal))
    {
        double dblDisplayVal = displayVal.toDouble();
        double dblDisplayValSign = -1 * dblDisplayVal;
        ui->InputText->setText(QString::number(dblDisplayValSign));
    }

}

void Form2::FunctionPressed()
{
    QString strNumber = ui->InputText->text();
        double number = strNumber.toDouble();

        QPushButton *button = (QPushButton *)sender();

        QString butVal = button->text();
        double resultVal = 0.0;

        if(QString::compare(butVal, "sin", Qt::CaseInsensitive) == 0 )
        {
            if(ui->Rad->text() == "dis_rad" && ui->Inv->text() == "inv")//rad
            {
                resultVal = sin(number);
            }
            else if(ui->Inv->text() == "dis_inv" && ui->Rad->text() == "dis_rad")//rad inv
            {
                resultVal = asin(number);
            }
            else if(ui->Inv->text() == "dis_inv" && ui->Rad->text() == "rad")//deg inv
            {
                resultVal = asin(number) * 180 / PI;
            }
            else if(ui->Rad->text() == "rad" && ui->Inv->text() == "inv")//deg
            {
                resultVal = sin(number * PI / 180);
            }
            //resultVal = sin(number);
        }
        else if(QString::compare(butVal, "cos", Qt::CaseInsensitive) == 0)
        {
            if(ui->Rad->text() == "dis_rad" && ui->Inv->text() == "inv")
            {
                resultVal = cos(number);
            }
            else if(ui->Inv->text() == "dis_inv" && ui->Rad->text() == "dis_rad")
            {
                resultVal = acos(number);
            }
            else if(ui->Inv->text() == "dis_inv" && ui->Rad->text() == "rad")
            {
                resultVal = acos(number) * 180 / PI;
            }
            else if(ui->Rad->text() == "rad" && ui->Inv->text() == "inv")
            {
                resultVal = cos(number * PI / 180);
            }
        }
        else if(QString::compare(butVal, "tan", Qt::CaseInsensitive) == 0)
        {
            if(ui->Rad->text() == "dis_rad" && ui->Inv->text() == "inv")
            {
                resultVal = tan(number);
            }
            else if(ui->Inv->text() == "dis_inv" && ui->Rad->text() == "dis_rad")
            {
                resultVal = atan(number);
            }
            else if(ui->Inv->text() == "dis_inv" && ui->Rad->text() == "rad")
            {
                resultVal = atan(number) * 180 / PI;
            }
            else if(ui->Rad->text() == "rad" && ui->Inv->text() == "inv")
            {
                resultVal = tan(number * PI / 180);
            }
        }
        else if(QString::compare(butVal, "cot", Qt::CaseInsensitive) == 0)
        {
            if(ui->Rad->text() == "dis_rad" && ui->Inv->text() == "inv")//rad
            {
                resultVal = pow(tan(number),-1);
            }
            else if(ui->Inv->text() == "dis_inv" && ui->Rad->text() == "dis_rad")//rad inv
            {
                resultVal = atan(pow(number,-1));
            }
            else if(ui->Inv->text() == "dis_inv" && ui->Rad->text() == "rad")//deg inv
            {
                resultVal = atan(pow(number,-1)) * 180 / PI;
            }
            else if(ui->Rad->text() == "rad" && ui->Inv->text() == "inv")//deg
            {
                resultVal = pow(tan(number * PI / 180),-1);
            }
         }
        else if(QString::compare(butVal, "sec", Qt::CaseInsensitive) == 0)
        {
            if(ui->Rad->text() == "dis_rad" && ui->Inv->text() == "inv")//rad
            {
                resultVal = pow(cos(number),-1);
            }
            else if(ui->Inv->text() == "dis_inv" && ui->Rad->text() == "dis_rad")//rad inv
            {
                resultVal = acos(pow(number,-1));
            }
            else if(ui->Inv->text() == "dis_inv" && ui->Rad->text() == "rad")//deg inv
            {
                resultVal = acos(pow(number,-1)) * 180 / PI;
            }
            else if(ui->Rad->text() == "rad" && ui->Inv->text() == "inv")//deg
            {
                resultVal = pow(cos(number * PI / 180),-1);
            }
        }
        else if(QString::compare(butVal, "csc", Qt::CaseInsensitive) == 0)
        {
            if(ui->Rad->text() == "dis_rad" && ui->Inv->text() == "inv")//rad
            {
                resultVal = pow(sin(number),-1);
            }
            else if(ui->Inv->text() == "dis_inv" && ui->Rad->text() == "dis_rad")//rad inv
            {
                resultVal = asin(pow(number,-1));
            }
            else if(ui->Inv->text() == "dis_inv" && ui->Rad->text() == "rad")//deg inv
            {
                resultVal = asin(pow(number,-1)) * 180 / PI;
            }
            else if(ui->Rad->text() == "rad" && ui->Inv->text() == "inv")//deg
            {
                resultVal = pow(sin(number * PI / 180),-1);
            }
        }
        else
        {
            abort();
        }
        ui->OutputText->setText(QString::number(resultVal));
}

void Form2::NumPressed()
{
    QPushButton *button = (QPushButton *)sender();
        QString butVal = button->text();
        QString displayVal = ui->InputText->text();
        if(displayVal.contains("."))
        {
           if(displayVal.length() < 16)
           {
                QString newVal = displayVal + butVal;
                ui->InputText->setText(newVal);
           }
           else
           {
               QString newValOver = displayVal + butVal;
               double dbNewVal = newValOver.toDouble();
               ui->InputText->setText(QString::number(dbNewVal,'g',16));
           }
        }
        else
        {
        if((displayVal.toDouble() == 0)|| (displayVal.toDouble() == 0.0))
        {
            ui->InputText->setText(butVal);
        }
        else
        {
            QString newVal = displayVal + butVal;
            double dblNewVal = newVal.toDouble();
            ui->InputText->setText(QString::number(dblNewVal,'g',16));
        }
        }
}

void Form2::ClearText()
{
    QPushButton *button = (QPushButton *)sender();
    if(QString::compare(button->text(),"Clear",Qt::CaseInsensitive) == 0)
    {
        ui->InputText->setText("");
        ui->OutputText->setText("");
    }
}

void Form2::DotBtnPressed()
{
    if(ui->InputText->text().contains("."))
    {
        return;
    }
    else
    {
        ui->InputText->setText(ui->InputText->text()+tr("."));
    }
}

void Form2::CloseBtnPressed()
{
    this->close();
}

void Form2::on_Rad_clicked()
{
    if(ui->Rad->text() == "rad")
    {
       ui->Rad->setFixedSize(137,68);//固定样式
       ui->Rad->setStyleSheet(
       "QPushButton{"
       "background-color:#FFFFE0;"
       "color:rgba(255,0,0);"//红色
       "border: 5px solid rgb(178, 34, 34);"
       "}"
      "QPushButton:hover{"
      "border: 5px solid rgb(255, 165, 0);"
      "}");
       ui->Rad->setText("dis_rad");
    }
    else if(ui->Rad->text()=="dis_rad")
    {
      ui->Rad->setFixedSize(137, 68);
      ui->Rad->setStyleSheet(
      "QPushButton{"
      "background-color:#FFFFE0;"
      "border:5px solid grey;"
      "padding:5px;"
      "}"
      "QPushButton:hover{"
      "border: 5px solid rgb(0, 150, 136);"//橘红色
      "}");
      ui->Rad->setText("rad");
      //ui->pushButton->setStyleSheet("font: 11pt \"微软雅黑\";");
    }
}

void Form2::on_Inv_clicked()
{
    if(ui->Inv->text() == "inv")
    {
       ui->Inv->setFixedSize(137,68);//固定样式
       ui->Inv->setStyleSheet(
       "QPushButton{"
       "background-color:#FFFFE0;"
       "color:rgba(255,0,0);"//红色
       "border: 5px solid rgb(178, 34, 34);"
       "}"
      "QPushButton:hover{"
      "border: 5px solid rgb(255, 165, 0);"
      "}");
       ui->Inv->setText("dis_inv");
    }
    else if(ui->Inv->text()=="dis_inv")
    {
      ui->Inv->setFixedSize(137, 68);
      ui->Inv->setStyleSheet(
      "QPushButton{"
      "background-color:#FFFFE0;"
      "border:5px solid grey;"
      "padding:5px;"
      "}"
      "QPushButton:hover{"
      "border: 5px solid rgb(0, 150, 136);"//橘红色
      "}");
      ui->Inv->setText("inv");
      //ui->pushButton->setStyleSheet("font: 11pt \"微软雅黑\";");
    }
}


