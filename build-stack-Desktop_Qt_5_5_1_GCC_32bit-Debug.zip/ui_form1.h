/********************************************************************************
** Form generated from reading UI file 'form1.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FORM1_H
#define UI_FORM1_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Form1
{
public:
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout_3;
    QPushButton *seven;
    QPushButton *eight;
    QPushButton *nine;
    QPushButton *move;
    QLineEdit *lineEdit;
    QPushButton *equal;
    QWidget *layoutWidget_2;
    QHBoxLayout *horizontalLayout_5;
    QPushButton *one;
    QPushButton *two;
    QPushButton *three;
    QWidget *layoutWidget_3;
    QHBoxLayout *horizontalLayout_4;
    QPushButton *four;
    QPushButton *five;
    QPushButton *six;
    QWidget *layoutWidget_4;
    QHBoxLayout *horizontalLayout_2;
    QPushButton *zero;
    QPushButton *jia;
    QPushButton *jian;
    QPushButton *clear;
    QWidget *layoutWidget_5;
    QHBoxLayout *horizontalLayout;
    QPushButton *left;
    QPushButton *chen;
    QPushButton *chu;
    QPushButton *right;

    void setupUi(QWidget *Form1)
    {
        if (Form1->objectName().isEmpty())
            Form1->setObjectName(QStringLiteral("Form1"));
        Form1->resize(710, 490);
        layoutWidget = new QWidget(Form1);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(10, 270, 691, 61));
        QFont font;
        font.setPointSize(20);
        layoutWidget->setFont(font);
        horizontalLayout_3 = new QHBoxLayout(layoutWidget);
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        horizontalLayout_3->setContentsMargins(0, 0, 0, 0);
        seven = new QPushButton(layoutWidget);
        seven->setObjectName(QStringLiteral("seven"));
        QSizePolicy sizePolicy(QSizePolicy::Minimum, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(seven->sizePolicy().hasHeightForWidth());
        seven->setSizePolicy(sizePolicy);
        seven->setFont(font);

        horizontalLayout_3->addWidget(seven);

        eight = new QPushButton(layoutWidget);
        eight->setObjectName(QStringLiteral("eight"));
        sizePolicy.setHeightForWidth(eight->sizePolicy().hasHeightForWidth());
        eight->setSizePolicy(sizePolicy);
        eight->setFont(font);

        horizontalLayout_3->addWidget(eight);

        nine = new QPushButton(layoutWidget);
        nine->setObjectName(QStringLiteral("nine"));
        sizePolicy.setHeightForWidth(nine->sizePolicy().hasHeightForWidth());
        nine->setSizePolicy(sizePolicy);
        nine->setFont(font);

        horizontalLayout_3->addWidget(nine);

        move = new QPushButton(layoutWidget);
        move->setObjectName(QStringLiteral("move"));
        sizePolicy.setHeightForWidth(move->sizePolicy().hasHeightForWidth());
        move->setSizePolicy(sizePolicy);
        move->setFont(font);

        horizontalLayout_3->addWidget(move);

        lineEdit = new QLineEdit(Form1);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));
        lineEdit->setGeometry(QRect(20, 20, 661, 91));
        lineEdit->setFont(font);
        equal = new QPushButton(Form1);
        equal->setObjectName(QStringLiteral("equal"));
        equal->setGeometry(QRect(550, 350, 151, 101));
        equal->setFont(font);
        layoutWidget_2 = new QWidget(Form1);
        layoutWidget_2->setObjectName(QStringLiteral("layoutWidget_2"));
        layoutWidget_2->setGeometry(QRect(10, 410, 521, 61));
        layoutWidget_2->setFont(font);
        horizontalLayout_5 = new QHBoxLayout(layoutWidget_2);
        horizontalLayout_5->setObjectName(QStringLiteral("horizontalLayout_5"));
        horizontalLayout_5->setContentsMargins(0, 0, 0, 0);
        one = new QPushButton(layoutWidget_2);
        one->setObjectName(QStringLiteral("one"));
        sizePolicy.setHeightForWidth(one->sizePolicy().hasHeightForWidth());
        one->setSizePolicy(sizePolicy);
        one->setFont(font);

        horizontalLayout_5->addWidget(one);

        two = new QPushButton(layoutWidget_2);
        two->setObjectName(QStringLiteral("two"));
        sizePolicy.setHeightForWidth(two->sizePolicy().hasHeightForWidth());
        two->setSizePolicy(sizePolicy);
        two->setFont(font);

        horizontalLayout_5->addWidget(two);

        three = new QPushButton(layoutWidget_2);
        three->setObjectName(QStringLiteral("three"));
        sizePolicy.setHeightForWidth(three->sizePolicy().hasHeightForWidth());
        three->setSizePolicy(sizePolicy);
        three->setFont(font);

        horizontalLayout_5->addWidget(three);

        layoutWidget_3 = new QWidget(Form1);
        layoutWidget_3->setObjectName(QStringLiteral("layoutWidget_3"));
        layoutWidget_3->setGeometry(QRect(9, 338, 521, 61));
        layoutWidget_3->setFont(font);
        horizontalLayout_4 = new QHBoxLayout(layoutWidget_3);
        horizontalLayout_4->setObjectName(QStringLiteral("horizontalLayout_4"));
        horizontalLayout_4->setContentsMargins(0, 0, 0, 0);
        four = new QPushButton(layoutWidget_3);
        four->setObjectName(QStringLiteral("four"));
        sizePolicy.setHeightForWidth(four->sizePolicy().hasHeightForWidth());
        four->setSizePolicy(sizePolicy);
        four->setFont(font);

        horizontalLayout_4->addWidget(four);

        five = new QPushButton(layoutWidget_3);
        five->setObjectName(QStringLiteral("five"));
        sizePolicy.setHeightForWidth(five->sizePolicy().hasHeightForWidth());
        five->setSizePolicy(sizePolicy);
        five->setFont(font);

        horizontalLayout_4->addWidget(five);

        six = new QPushButton(layoutWidget_3);
        six->setObjectName(QStringLiteral("six"));
        sizePolicy.setHeightForWidth(six->sizePolicy().hasHeightForWidth());
        six->setSizePolicy(sizePolicy);
        six->setFont(font);

        horizontalLayout_4->addWidget(six);

        layoutWidget_4 = new QWidget(Form1);
        layoutWidget_4->setObjectName(QStringLiteral("layoutWidget_4"));
        layoutWidget_4->setGeometry(QRect(10, 200, 691, 61));
        layoutWidget_4->setFont(font);
        horizontalLayout_2 = new QHBoxLayout(layoutWidget_4);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        zero = new QPushButton(layoutWidget_4);
        zero->setObjectName(QStringLiteral("zero"));
        sizePolicy.setHeightForWidth(zero->sizePolicy().hasHeightForWidth());
        zero->setSizePolicy(sizePolicy);
        zero->setFont(font);

        horizontalLayout_2->addWidget(zero);

        jia = new QPushButton(layoutWidget_4);
        jia->setObjectName(QStringLiteral("jia"));
        sizePolicy.setHeightForWidth(jia->sizePolicy().hasHeightForWidth());
        jia->setSizePolicy(sizePolicy);
        jia->setFont(font);

        horizontalLayout_2->addWidget(jia);

        jian = new QPushButton(layoutWidget_4);
        jian->setObjectName(QStringLiteral("jian"));
        sizePolicy.setHeightForWidth(jian->sizePolicy().hasHeightForWidth());
        jian->setSizePolicy(sizePolicy);
        jian->setFont(font);

        horizontalLayout_2->addWidget(jian);

        clear = new QPushButton(layoutWidget_4);
        clear->setObjectName(QStringLiteral("clear"));
        sizePolicy.setHeightForWidth(clear->sizePolicy().hasHeightForWidth());
        clear->setSizePolicy(sizePolicy);
        clear->setFont(font);

        horizontalLayout_2->addWidget(clear);

        layoutWidget_5 = new QWidget(Form1);
        layoutWidget_5->setObjectName(QStringLiteral("layoutWidget_5"));
        layoutWidget_5->setGeometry(QRect(10, 130, 691, 61));
        layoutWidget_5->setFont(font);
        horizontalLayout = new QHBoxLayout(layoutWidget_5);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        left = new QPushButton(layoutWidget_5);
        left->setObjectName(QStringLiteral("left"));
        sizePolicy.setHeightForWidth(left->sizePolicy().hasHeightForWidth());
        left->setSizePolicy(sizePolicy);
        left->setFont(font);

        horizontalLayout->addWidget(left);

        chen = new QPushButton(layoutWidget_5);
        chen->setObjectName(QStringLiteral("chen"));
        sizePolicy.setHeightForWidth(chen->sizePolicy().hasHeightForWidth());
        chen->setSizePolicy(sizePolicy);
        chen->setFont(font);

        horizontalLayout->addWidget(chen);

        chu = new QPushButton(layoutWidget_5);
        chu->setObjectName(QStringLiteral("chu"));
        sizePolicy.setHeightForWidth(chu->sizePolicy().hasHeightForWidth());
        chu->setSizePolicy(sizePolicy);
        chu->setFont(font);

        horizontalLayout->addWidget(chu);

        right = new QPushButton(layoutWidget_5);
        right->setObjectName(QStringLiteral("right"));
        sizePolicy.setHeightForWidth(right->sizePolicy().hasHeightForWidth());
        right->setSizePolicy(sizePolicy);
        right->setFont(font);

        horizontalLayout->addWidget(right);


        retranslateUi(Form1);

        QMetaObject::connectSlotsByName(Form1);
    } // setupUi

    void retranslateUi(QWidget *Form1)
    {
        Form1->setWindowTitle(QApplication::translate("Form1", "Form", 0));
        seven->setText(QApplication::translate("Form1", "7", 0));
        eight->setText(QApplication::translate("Form1", "8", 0));
        nine->setText(QApplication::translate("Form1", "9", 0));
        move->setText(QApplication::translate("Form1", "\342\206\220", 0));
        equal->setText(QApplication::translate("Form1", "=", 0));
        one->setText(QApplication::translate("Form1", "1", 0));
        two->setText(QApplication::translate("Form1", "2", 0));
        three->setText(QApplication::translate("Form1", "3", 0));
        four->setText(QApplication::translate("Form1", "4", 0));
        five->setText(QApplication::translate("Form1", "5", 0));
        six->setText(QApplication::translate("Form1", "6", 0));
        zero->setText(QApplication::translate("Form1", "0", 0));
        jia->setText(QApplication::translate("Form1", "+", 0));
        jian->setText(QApplication::translate("Form1", "-", 0));
        clear->setText(QApplication::translate("Form1", "C", 0));
        left->setText(QApplication::translate("Form1", "(", 0));
        chen->setText(QApplication::translate("Form1", "\303\227", 0));
        chu->setText(QApplication::translate("Form1", "\303\267", 0));
        right->setText(QApplication::translate("Form1", ")", 0));
    } // retranslateUi

};

namespace Ui {
    class Form1: public Ui_Form1 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FORM1_H
