/********************************************************************************
** Form generated from reading UI file 'form2.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FORM2_H
#define UI_FORM2_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Form2
{
public:
    QWidget *widget;
    QGridLayout *gridLayout;
    QPushButton *Button3;
    QPushButton *Inv;
    QPushButton *Dot;
    QPushButton *Tan;
    QPushButton *Cot;
    QPushButton *Cos;
    QPushButton *Button6;
    QPushButton *Sec;
    QPushButton *Button0;
    QPushButton *Csc;
    QPushButton *Button7;
    QPushButton *Button5;
    QPushButton *Sin;
    QPushButton *Button9;
    QPushButton *Button1;
    QPushButton *ChangeSign;
    QPushButton *Rad;
    QPushButton *Button2;
    QPushButton *Button8;
    QPushButton *Button4;
    QWidget *widget1;
    QHBoxLayout *horizontalLayout;
    QLineEdit *InputText;
    QLineEdit *OutputText;
    QWidget *widget2;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label;
    QPushButton *Clear;
    QLabel *label_2;
    QPushButton *Close;

    void setupUi(QWidget *Form2)
    {
        if (Form2->objectName().isEmpty())
            Form2->setObjectName(QStringLiteral("Form2"));
        Form2->resize(760, 505);
        widget = new QWidget(Form2);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setGeometry(QRect(10, 200, 711, 291));
        gridLayout = new QGridLayout(widget);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        Button3 = new QPushButton(widget);
        Button3->setObjectName(QStringLiteral("Button3"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(Button3->sizePolicy().hasHeightForWidth());
        Button3->setSizePolicy(sizePolicy);
        QPalette palette;
        QBrush brush(QColor(173, 234, 234, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Button, brush);
        palette.setBrush(QPalette::Active, QPalette::Base, brush);
        palette.setBrush(QPalette::Active, QPalette::Window, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Base, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Window, brush);
        palette.setBrush(QPalette::Disabled, QPalette::Button, brush);
        palette.setBrush(QPalette::Disabled, QPalette::Base, brush);
        palette.setBrush(QPalette::Disabled, QPalette::Window, brush);
        Button3->setPalette(palette);
        QFont font;
        font.setPointSize(18);
        Button3->setFont(font);
        Button3->setStyleSheet(QLatin1String("QPushButton{\n"
"	background-color:#ADEAEA;\n"
"	border:5px solid grey;\n"
"	padding:5px;\n"
"}\n"
"\n"
"QPushButton:press{\n"
"	background-color:#3299CC;\n"
"	border:5px solid grey;\n"
"	padding:5px;\n"
"}"));

        gridLayout->addWidget(Button3, 0, 3, 1, 1);

        Inv = new QPushButton(widget);
        Inv->setObjectName(QStringLiteral("Inv"));
        sizePolicy.setHeightForWidth(Inv->sizePolicy().hasHeightForWidth());
        Inv->setSizePolicy(sizePolicy);
        QFont font1;
        font1.setPointSize(20);
        Inv->setFont(font1);
        Inv->setStyleSheet(QLatin1String("QPushButton{\n"
"	background-color:#FFFFE0;\n"
"	border:5px solid grey;\n"
"	padding:5px;\n"
"}"));

        gridLayout->addWidget(Inv, 3, 4, 1, 1);

        Dot = new QPushButton(widget);
        Dot->setObjectName(QStringLiteral("Dot"));
        sizePolicy.setHeightForWidth(Dot->sizePolicy().hasHeightForWidth());
        Dot->setSizePolicy(sizePolicy);
        Dot->setFont(font1);
        Dot->setStyleSheet(QLatin1String("QPushButton{\n"
"	background-color:#FFFFE0;\n"
"	border:5px solid grey;\n"
"	padding:5px;\n"
"}"));

        gridLayout->addWidget(Dot, 0, 4, 1, 1);

        Tan = new QPushButton(widget);
        Tan->setObjectName(QStringLiteral("Tan"));
        sizePolicy.setHeightForWidth(Tan->sizePolicy().hasHeightForWidth());
        Tan->setSizePolicy(sizePolicy);
        Tan->setFont(font1);
        Tan->setStyleSheet(QLatin1String("QPushButton{\n"
"	background-color:#B0C4DE;\n"
"	border:4px solid grey;\n"
"	padding:5px;\n"
"}\n"
"\n"
"QPushButton:press{\n"
"	background-color:#6495ED;\n"
"	border:1px solid grey;\n"
"	padding:5px;\n"
"}"));

        gridLayout->addWidget(Tan, 1, 1, 1, 1);

        Cot = new QPushButton(widget);
        Cot->setObjectName(QStringLiteral("Cot"));
        sizePolicy.setHeightForWidth(Cot->sizePolicy().hasHeightForWidth());
        Cot->setSizePolicy(sizePolicy);
        Cot->setFont(font1);
        Cot->setStyleSheet(QLatin1String("QPushButton{\n"
"	background-color:#B0C4DE;\n"
"	border:4px solid grey;\n"
"	padding:5px;\n"
"}\n"
"\n"
"QPushButton:press{\n"
"	background-color:#6495ED;\n"
"	border:1px solid grey;\n"
"	padding:5px;\n"
"}"));

        gridLayout->addWidget(Cot, 2, 1, 1, 1);

        Cos = new QPushButton(widget);
        Cos->setObjectName(QStringLiteral("Cos"));
        sizePolicy.setHeightForWidth(Cos->sizePolicy().hasHeightForWidth());
        Cos->setSizePolicy(sizePolicy);
        Cos->setFont(font1);
        Cos->setStyleSheet(QLatin1String("QPushButton{\n"
"	background-color:#B0C4DE;\n"
"	border:4px solid grey;\n"
"	padding:5px;\n"
"}\n"
"\n"
"QPushButton:press{\n"
"	background-color:#6495ED;\n"
"	border:1px solid grey;\n"
"	padding:5px;\n"
"}"));

        gridLayout->addWidget(Cos, 2, 0, 1, 1);

        Button6 = new QPushButton(widget);
        Button6->setObjectName(QStringLiteral("Button6"));
        sizePolicy.setHeightForWidth(Button6->sizePolicy().hasHeightForWidth());
        Button6->setSizePolicy(sizePolicy);
        QPalette palette1;
        palette1.setBrush(QPalette::Active, QPalette::Button, brush);
        palette1.setBrush(QPalette::Active, QPalette::Base, brush);
        palette1.setBrush(QPalette::Active, QPalette::Window, brush);
        palette1.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette1.setBrush(QPalette::Inactive, QPalette::Base, brush);
        palette1.setBrush(QPalette::Inactive, QPalette::Window, brush);
        palette1.setBrush(QPalette::Disabled, QPalette::Button, brush);
        palette1.setBrush(QPalette::Disabled, QPalette::Base, brush);
        palette1.setBrush(QPalette::Disabled, QPalette::Window, brush);
        Button6->setPalette(palette1);
        Button6->setFont(font);
        Button6->setStyleSheet(QLatin1String("QPushButton{\n"
"	background-color:#ADEAEA;\n"
"	border:5px solid grey;\n"
"	padding:5px;\n"
"}\n"
"\n"
"QPushButton:press{\n"
"	background-color:#3299CC;\n"
"	border:5px solid grey;\n"
"	padding:5px;\n"
"}"));

        gridLayout->addWidget(Button6, 2, 2, 1, 1);

        Sec = new QPushButton(widget);
        Sec->setObjectName(QStringLiteral("Sec"));
        sizePolicy.setHeightForWidth(Sec->sizePolicy().hasHeightForWidth());
        Sec->setSizePolicy(sizePolicy);
        Sec->setFont(font1);
        Sec->setStyleSheet(QLatin1String("QPushButton{\n"
"	background-color:#B0C4DE;\n"
"	border:4px solid grey;\n"
"	padding:5px;\n"
"}\n"
"\n"
"QPushButton:press{\n"
"	background-color:#6495ED;\n"
"	border:1px solid grey;\n"
"	padding:5px;\n"
"}"));

        gridLayout->addWidget(Sec, 3, 0, 1, 1);

        Button0 = new QPushButton(widget);
        Button0->setObjectName(QStringLiteral("Button0"));
        sizePolicy.setHeightForWidth(Button0->sizePolicy().hasHeightForWidth());
        Button0->setSizePolicy(sizePolicy);
        QPalette palette2;
        palette2.setBrush(QPalette::Active, QPalette::Button, brush);
        palette2.setBrush(QPalette::Active, QPalette::Base, brush);
        palette2.setBrush(QPalette::Active, QPalette::Window, brush);
        palette2.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette2.setBrush(QPalette::Inactive, QPalette::Base, brush);
        palette2.setBrush(QPalette::Inactive, QPalette::Window, brush);
        palette2.setBrush(QPalette::Disabled, QPalette::Button, brush);
        palette2.setBrush(QPalette::Disabled, QPalette::Base, brush);
        palette2.setBrush(QPalette::Disabled, QPalette::Window, brush);
        Button0->setPalette(palette2);
        Button0->setFont(font);
        Button0->setStyleSheet(QLatin1String("QPushButton{\n"
"	background-color:#ADEAEA;\n"
"	border:5px solid grey;\n"
"	padding:5px;\n"
"}\n"
"\n"
"QPushButton:press{\n"
"	background-color:#3299CC;\n"
"	border:5px solid grey;\n"
"	padding:5px;\n"
"}"));

        gridLayout->addWidget(Button0, 0, 0, 1, 1);

        Csc = new QPushButton(widget);
        Csc->setObjectName(QStringLiteral("Csc"));
        sizePolicy.setHeightForWidth(Csc->sizePolicy().hasHeightForWidth());
        Csc->setSizePolicy(sizePolicy);
        Csc->setFont(font1);
        Csc->setStyleSheet(QLatin1String("QPushButton{\n"
"	background-color:#B0C4DE;\n"
"	border:4px solid grey;\n"
"	padding:5px;\n"
"}\n"
"\n"
"QPushButton:press{\n"
"	background-color:#6495ED;\n"
"	border:1px solid grey;\n"
"	padding:5px;\n"
"}"));

        gridLayout->addWidget(Csc, 3, 1, 1, 1);

        Button7 = new QPushButton(widget);
        Button7->setObjectName(QStringLiteral("Button7"));
        sizePolicy.setHeightForWidth(Button7->sizePolicy().hasHeightForWidth());
        Button7->setSizePolicy(sizePolicy);
        QPalette palette3;
        palette3.setBrush(QPalette::Active, QPalette::Button, brush);
        palette3.setBrush(QPalette::Active, QPalette::Base, brush);
        palette3.setBrush(QPalette::Active, QPalette::Window, brush);
        palette3.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette3.setBrush(QPalette::Inactive, QPalette::Base, brush);
        palette3.setBrush(QPalette::Inactive, QPalette::Window, brush);
        palette3.setBrush(QPalette::Disabled, QPalette::Button, brush);
        palette3.setBrush(QPalette::Disabled, QPalette::Base, brush);
        palette3.setBrush(QPalette::Disabled, QPalette::Window, brush);
        Button7->setPalette(palette3);
        Button7->setFont(font);
        Button7->setStyleSheet(QLatin1String("QPushButton{\n"
"	background-color:#ADEAEA;\n"
"	border:5px solid grey;\n"
"	padding:5px;\n"
"}\n"
"\n"
"QPushButton:press{\n"
"	background-color:#3299CC;\n"
"	border:5px solid grey;\n"
"	padding:5px;\n"
"}"));

        gridLayout->addWidget(Button7, 2, 3, 1, 1);

        Button5 = new QPushButton(widget);
        Button5->setObjectName(QStringLiteral("Button5"));
        sizePolicy.setHeightForWidth(Button5->sizePolicy().hasHeightForWidth());
        Button5->setSizePolicy(sizePolicy);
        QPalette palette4;
        palette4.setBrush(QPalette::Active, QPalette::Button, brush);
        palette4.setBrush(QPalette::Active, QPalette::Base, brush);
        palette4.setBrush(QPalette::Active, QPalette::Window, brush);
        palette4.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette4.setBrush(QPalette::Inactive, QPalette::Base, brush);
        palette4.setBrush(QPalette::Inactive, QPalette::Window, brush);
        palette4.setBrush(QPalette::Disabled, QPalette::Button, brush);
        palette4.setBrush(QPalette::Disabled, QPalette::Base, brush);
        palette4.setBrush(QPalette::Disabled, QPalette::Window, brush);
        Button5->setPalette(palette4);
        Button5->setFont(font);
        Button5->setStyleSheet(QLatin1String("QPushButton{\n"
"	background-color:#ADEAEA;\n"
"	border:5px solid grey;\n"
"	padding:5px;\n"
"}\n"
"\n"
"QPushButton:press{\n"
"	background-color:#3299CC;\n"
"	border:5px solid grey;\n"
"	padding:5px;\n"
"}"));

        gridLayout->addWidget(Button5, 1, 3, 1, 1);

        Sin = new QPushButton(widget);
        Sin->setObjectName(QStringLiteral("Sin"));
        sizePolicy.setHeightForWidth(Sin->sizePolicy().hasHeightForWidth());
        Sin->setSizePolicy(sizePolicy);
        Sin->setFont(font1);
        Sin->setStyleSheet(QLatin1String("QPushButton{\n"
"	background-color:#B0C4DE;\n"
"	border:4px solid grey;\n"
"	padding:5px;\n"
"}\n"
"\n"
"QPushButton:press{\n"
"	background-color:#6495ED;\n"
"	border:1px solid grey;\n"
"	padding:5px;\n"
"}"));

        gridLayout->addWidget(Sin, 1, 0, 1, 1);

        Button9 = new QPushButton(widget);
        Button9->setObjectName(QStringLiteral("Button9"));
        sizePolicy.setHeightForWidth(Button9->sizePolicy().hasHeightForWidth());
        Button9->setSizePolicy(sizePolicy);
        QPalette palette5;
        palette5.setBrush(QPalette::Active, QPalette::Button, brush);
        palette5.setBrush(QPalette::Active, QPalette::Base, brush);
        palette5.setBrush(QPalette::Active, QPalette::Window, brush);
        palette5.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette5.setBrush(QPalette::Inactive, QPalette::Base, brush);
        palette5.setBrush(QPalette::Inactive, QPalette::Window, brush);
        palette5.setBrush(QPalette::Disabled, QPalette::Button, brush);
        palette5.setBrush(QPalette::Disabled, QPalette::Base, brush);
        palette5.setBrush(QPalette::Disabled, QPalette::Window, brush);
        Button9->setPalette(palette5);
        Button9->setFont(font);
        Button9->setStyleSheet(QLatin1String("QPushButton{\n"
"	background-color:#ADEAEA;\n"
"	border:5px solid grey;\n"
"	padding:5px;\n"
"}\n"
"\n"
"QPushButton:press{\n"
"	background-color:#3299CC;\n"
"	border:5px solid grey;\n"
"	padding:5px;\n"
"}"));

        gridLayout->addWidget(Button9, 3, 3, 1, 1);

        Button1 = new QPushButton(widget);
        Button1->setObjectName(QStringLiteral("Button1"));
        sizePolicy.setHeightForWidth(Button1->sizePolicy().hasHeightForWidth());
        Button1->setSizePolicy(sizePolicy);
        QPalette palette6;
        palette6.setBrush(QPalette::Active, QPalette::Button, brush);
        palette6.setBrush(QPalette::Active, QPalette::Base, brush);
        palette6.setBrush(QPalette::Active, QPalette::Window, brush);
        palette6.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette6.setBrush(QPalette::Inactive, QPalette::Base, brush);
        palette6.setBrush(QPalette::Inactive, QPalette::Window, brush);
        palette6.setBrush(QPalette::Disabled, QPalette::Button, brush);
        palette6.setBrush(QPalette::Disabled, QPalette::Base, brush);
        palette6.setBrush(QPalette::Disabled, QPalette::Window, brush);
        Button1->setPalette(palette6);
        Button1->setFont(font);
        Button1->setStyleSheet(QLatin1String("QPushButton{\n"
"	background-color:#ADEAEA;\n"
"	border:5px solid grey;\n"
"	padding:5px;\n"
"}\n"
"\n"
"QPushButton:press{\n"
"	background-color:#3299CC;\n"
"	border:5px solid grey;\n"
"	padding:5px;\n"
"}"));

        gridLayout->addWidget(Button1, 0, 1, 1, 1);

        ChangeSign = new QPushButton(widget);
        ChangeSign->setObjectName(QStringLiteral("ChangeSign"));
        sizePolicy.setHeightForWidth(ChangeSign->sizePolicy().hasHeightForWidth());
        ChangeSign->setSizePolicy(sizePolicy);
        ChangeSign->setFont(font1);
        ChangeSign->setStyleSheet(QLatin1String("QPushButton{\n"
"	background-color:#FFFFE0;\n"
"	border:5px solid grey;\n"
"	padding:5px;\n"
"}"));

        gridLayout->addWidget(ChangeSign, 1, 4, 1, 1);

        Rad = new QPushButton(widget);
        Rad->setObjectName(QStringLiteral("Rad"));
        sizePolicy.setHeightForWidth(Rad->sizePolicy().hasHeightForWidth());
        Rad->setSizePolicy(sizePolicy);
        Rad->setFont(font1);
        Rad->setStyleSheet(QLatin1String("QPushButton{\n"
"	background-color:#FFFFE0;\n"
"	border:5px solid grey;\n"
"	padding:5px;\n"
"}"));

        gridLayout->addWidget(Rad, 2, 4, 1, 1);

        Button2 = new QPushButton(widget);
        Button2->setObjectName(QStringLiteral("Button2"));
        sizePolicy.setHeightForWidth(Button2->sizePolicy().hasHeightForWidth());
        Button2->setSizePolicy(sizePolicy);
        QPalette palette7;
        palette7.setBrush(QPalette::Active, QPalette::Button, brush);
        palette7.setBrush(QPalette::Active, QPalette::Base, brush);
        palette7.setBrush(QPalette::Active, QPalette::Window, brush);
        palette7.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette7.setBrush(QPalette::Inactive, QPalette::Base, brush);
        palette7.setBrush(QPalette::Inactive, QPalette::Window, brush);
        palette7.setBrush(QPalette::Disabled, QPalette::Button, brush);
        palette7.setBrush(QPalette::Disabled, QPalette::Base, brush);
        palette7.setBrush(QPalette::Disabled, QPalette::Window, brush);
        Button2->setPalette(palette7);
        Button2->setFont(font);
        Button2->setStyleSheet(QLatin1String("QPushButton{\n"
"	background-color:#ADEAEA;\n"
"	border:5px solid grey;\n"
"	padding:5px;\n"
"}\n"
"\n"
"QPushButton:press{\n"
"	background-color:#3299CC;\n"
"	border:5px solid grey;\n"
"	padding:5px;\n"
"}"));

        gridLayout->addWidget(Button2, 0, 2, 1, 1);

        Button8 = new QPushButton(widget);
        Button8->setObjectName(QStringLiteral("Button8"));
        sizePolicy.setHeightForWidth(Button8->sizePolicy().hasHeightForWidth());
        Button8->setSizePolicy(sizePolicy);
        QPalette palette8;
        palette8.setBrush(QPalette::Active, QPalette::Button, brush);
        palette8.setBrush(QPalette::Active, QPalette::Base, brush);
        palette8.setBrush(QPalette::Active, QPalette::Window, brush);
        palette8.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette8.setBrush(QPalette::Inactive, QPalette::Base, brush);
        palette8.setBrush(QPalette::Inactive, QPalette::Window, brush);
        palette8.setBrush(QPalette::Disabled, QPalette::Button, brush);
        palette8.setBrush(QPalette::Disabled, QPalette::Base, brush);
        palette8.setBrush(QPalette::Disabled, QPalette::Window, brush);
        Button8->setPalette(palette8);
        Button8->setFont(font);
        Button8->setStyleSheet(QLatin1String("QPushButton{\n"
"	background-color:#ADEAEA;\n"
"	border:5px solid grey;\n"
"	padding:5px;\n"
"}\n"
"\n"
"QPushButton:press{\n"
"	background-color:#3299CC;\n"
"	border:5px solid grey;\n"
"	padding:5px;\n"
"}"));

        gridLayout->addWidget(Button8, 3, 2, 1, 1);

        Button4 = new QPushButton(widget);
        Button4->setObjectName(QStringLiteral("Button4"));
        sizePolicy.setHeightForWidth(Button4->sizePolicy().hasHeightForWidth());
        Button4->setSizePolicy(sizePolicy);
        QPalette palette9;
        palette9.setBrush(QPalette::Active, QPalette::Button, brush);
        palette9.setBrush(QPalette::Active, QPalette::Base, brush);
        palette9.setBrush(QPalette::Active, QPalette::Window, brush);
        palette9.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette9.setBrush(QPalette::Inactive, QPalette::Base, brush);
        palette9.setBrush(QPalette::Inactive, QPalette::Window, brush);
        palette9.setBrush(QPalette::Disabled, QPalette::Button, brush);
        palette9.setBrush(QPalette::Disabled, QPalette::Base, brush);
        palette9.setBrush(QPalette::Disabled, QPalette::Window, brush);
        Button4->setPalette(palette9);
        Button4->setFont(font);
        Button4->setStyleSheet(QLatin1String("QPushButton{\n"
"	background-color:#ADEAEA;\n"
"	border:5px solid grey;\n"
"	padding:5px;\n"
"}\n"
"\n"
"QPushButton:press{\n"
"	background-color:#3299CC;\n"
"	border:5px solid grey;\n"
"	padding:5px;\n"
"}"));

        gridLayout->addWidget(Button4, 1, 2, 1, 1);

        widget1 = new QWidget(Form2);
        widget1->setObjectName(QStringLiteral("widget1"));
        widget1->setGeometry(QRect(20, 100, 681, 91));
        horizontalLayout = new QHBoxLayout(widget1);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        InputText = new QLineEdit(widget1);
        InputText->setObjectName(QStringLiteral("InputText"));
        QSizePolicy sizePolicy1(QSizePolicy::Expanding, QSizePolicy::Preferred);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(InputText->sizePolicy().hasHeightForWidth());
        InputText->setSizePolicy(sizePolicy1);
        QFont font2;
        font2.setPointSize(22);
        InputText->setFont(font2);
        InputText->setLayoutDirection(Qt::LeftToRight);
        InputText->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        horizontalLayout->addWidget(InputText);

        OutputText = new QLineEdit(widget1);
        OutputText->setObjectName(QStringLiteral("OutputText"));
        sizePolicy1.setHeightForWidth(OutputText->sizePolicy().hasHeightForWidth());
        OutputText->setSizePolicy(sizePolicy1);
        OutputText->setFont(font2);
        OutputText->setLayoutDirection(Qt::LeftToRight);
        OutputText->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        horizontalLayout->addWidget(OutputText);

        widget2 = new QWidget(Form2);
        widget2->setObjectName(QStringLiteral("widget2"));
        widget2->setGeometry(QRect(20, 10, 681, 71));
        horizontalLayout_2 = new QHBoxLayout(widget2);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(widget2);
        label->setObjectName(QStringLiteral("label"));
        sizePolicy.setHeightForWidth(label->sizePolicy().hasHeightForWidth());
        label->setSizePolicy(sizePolicy);
        label->setFont(font);

        horizontalLayout_2->addWidget(label);

        Clear = new QPushButton(widget2);
        Clear->setObjectName(QStringLiteral("Clear"));
        sizePolicy.setHeightForWidth(Clear->sizePolicy().hasHeightForWidth());
        Clear->setSizePolicy(sizePolicy);
        QPalette palette10;
        QBrush brush1(QColor(43, 237, 20, 255));
        brush1.setStyle(Qt::SolidPattern);
        palette10.setBrush(QPalette::Active, QPalette::ButtonText, brush1);
        palette10.setBrush(QPalette::Inactive, QPalette::ButtonText, brush1);
        QBrush brush2(QColor(128, 161, 190, 255));
        brush2.setStyle(Qt::SolidPattern);
        palette10.setBrush(QPalette::Disabled, QPalette::ButtonText, brush2);
        Clear->setPalette(palette10);
        QFont font3;
        font3.setPointSize(16);
        Clear->setFont(font3);

        horizontalLayout_2->addWidget(Clear);

        label_2 = new QLabel(widget2);
        label_2->setObjectName(QStringLiteral("label_2"));
        sizePolicy.setHeightForWidth(label_2->sizePolicy().hasHeightForWidth());
        label_2->setSizePolicy(sizePolicy);
        label_2->setFont(font);

        horizontalLayout_2->addWidget(label_2);

        Close = new QPushButton(widget2);
        Close->setObjectName(QStringLiteral("Close"));
        sizePolicy.setHeightForWidth(Close->sizePolicy().hasHeightForWidth());
        Close->setSizePolicy(sizePolicy);
        Close->setFont(font3);
        Close->setStyleSheet(QLatin1String("QPushButton:hover{\n"
"border: 5px solid DC143C;}"));

        horizontalLayout_2->addWidget(Close);


        retranslateUi(Form2);

        QMetaObject::connectSlotsByName(Form2);
    } // setupUi

    void retranslateUi(QWidget *Form2)
    {
        Form2->setWindowTitle(QApplication::translate("Form2", "Form", 0));
        Button3->setText(QApplication::translate("Form2", "3", 0));
        Inv->setText(QApplication::translate("Form2", "inv", 0));
        Dot->setText(QApplication::translate("Form2", ".", 0));
        Tan->setText(QApplication::translate("Form2", "tan", 0));
        Cot->setText(QApplication::translate("Form2", "cot", 0));
        Cos->setText(QApplication::translate("Form2", "cos", 0));
        Button6->setText(QApplication::translate("Form2", "6", 0));
        Sec->setText(QApplication::translate("Form2", "sec", 0));
        Button0->setText(QApplication::translate("Form2", "0", 0));
        Csc->setText(QApplication::translate("Form2", "csc", 0));
        Button7->setText(QApplication::translate("Form2", "7", 0));
        Button5->setText(QApplication::translate("Form2", "5", 0));
        Sin->setText(QApplication::translate("Form2", "sin", 0));
        Button9->setText(QApplication::translate("Form2", "9", 0));
        Button1->setText(QApplication::translate("Form2", "1", 0));
        ChangeSign->setText(QApplication::translate("Form2", "+/-", 0));
        Rad->setText(QApplication::translate("Form2", "rad", 0));
        Button2->setText(QApplication::translate("Form2", "2", 0));
        Button8->setText(QApplication::translate("Form2", "8", 0));
        Button4->setText(QApplication::translate("Form2", "4", 0));
        label->setText(QApplication::translate("Form2", "\350\276\223\345\205\245", 0));
        Clear->setText(QApplication::translate("Form2", "Clear", 0));
        label_2->setText(QApplication::translate("Form2", "\350\276\223\345\207\272", 0));
        Close->setText(QApplication::translate("Form2", "Quit", 0));
    } // retranslateUi

};

namespace Ui {
    class Form2: public Ui_Form2 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FORM2_H
