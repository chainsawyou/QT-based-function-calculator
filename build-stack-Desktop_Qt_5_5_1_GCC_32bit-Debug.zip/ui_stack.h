/********************************************************************************
** Form generated from reading UI file 'stack.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_STACK_H
#define UI_STACK_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_stack
{
public:

    void setupUi(QWidget *stack)
    {
        if (stack->objectName().isEmpty())
            stack->setObjectName(QStringLiteral("stack"));
        stack->resize(400, 300);

        retranslateUi(stack);

        QMetaObject::connectSlotsByName(stack);
    } // setupUi

    void retranslateUi(QWidget *stack)
    {
        stack->setWindowTitle(QApplication::translate("stack", "stack", 0));
    } // retranslateUi

};

namespace Ui {
    class stack: public Ui_stack {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_STACK_H
