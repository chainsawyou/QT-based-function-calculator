/********************************************************************************
** Form generated from reading UI file 'lineseries.ui'
**
** Created by: Qt User Interface Compiler version 5.9.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LINESERIES_H
#define UI_LINESERIES_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QToolButton>
#include <QtWidgets/QWidget>
//#include <qchartview.h>

QT_BEGIN_NAMESPACE

class Ui_lineseries
{
public:
    QToolButton *toolButton;
    QToolButton *toolButton_2;
    QChartView *graphicsView1;
    QChartView *graphicsView2;

    void setupUi(QWidget *lineseries)
    {
        if (lineseries->objectName().isEmpty())
            lineseries->setObjectName(QStringLiteral("lineseries"));
        lineseries->resize(1143, 620);
        toolButton = new QToolButton(lineseries);
        toolButton->setObjectName(QStringLiteral("toolButton"));
        toolButton->setGeometry(QRect(750, 60, 131, 41));
        toolButton->setStyleSheet(QStringLiteral("font: 14pt \"Adobe Arabic\";"));
        toolButton->setAutoRaise(true);
        toolButton_2 = new QToolButton(lineseries);
        toolButton_2->setObjectName(QStringLiteral("toolButton_2"));
        toolButton_2->setGeometry(QRect(170, 50, 131, 51));
        toolButton_2->setStyleSheet(QStringLiteral("font: 14pt \"Adobe Arabic\";"));
        toolButton_2->setAutoRaise(true);
        graphicsView1 = new QChartView(lineseries);
        graphicsView1->setObjectName(QStringLiteral("graphicsView1"));
        graphicsView1->setGeometry(QRect(10, 110, 531, 441));
        graphicsView2 = new QChartView(lineseries);
        graphicsView2->setObjectName(QStringLiteral("graphicsView2"));
        graphicsView2->setGeometry(QRect(580, 110, 531, 441));

        retranslateUi(lineseries);

        QMetaObject::connectSlotsByName(lineseries);
    } // setupUi

    void retranslateUi(QWidget *lineseries)
    {
        lineseries->setWindowTitle(QApplication::translate("lineseries", "\346\265\213\351\200\237\345\233\276", Q_NULLPTR));
        toolButton->setText(QApplication::translate("lineseries", "\346\212\230\347\272\277\345\233\276", Q_NULLPTR));
        toolButton_2->setText(QApplication::translate("lineseries", "\346\233\262\347\272\277\345\233\276", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class lineseries: public Ui_lineseries {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LINESERIES_H
