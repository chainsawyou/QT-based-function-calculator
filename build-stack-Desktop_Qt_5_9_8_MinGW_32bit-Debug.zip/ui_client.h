/********************************************************************************
** Form generated from reading UI file 'client.ui'
**
** Created by: Qt User Interface Compiler version 5.9.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CLIENT_H
#define UI_CLIENT_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_client
{
public:
    QLabel *label;
    QLabel *label_2;
    QLineEdit *lineEditIP;
    QLineEdit *lineEditPort;
    QTextEdit *textEditRead;
    QLabel *label_3;
    QTextEdit *textEditWrite;
    QLabel *label_4;
    QPushButton *buttonsend;
    QPushButton *buttonclose;
    QPushButton *buttonconnect;

    void setupUi(QWidget *client)
    {
        if (client->objectName().isEmpty())
            client->setObjectName(QStringLiteral("client"));
        client->resize(720, 504);
        label = new QLabel(client);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(90, 20, 101, 41));
        label_2 = new QLabel(client);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(120, 100, 72, 15));
        lineEditIP = new QLineEdit(client);
        lineEditIP->setObjectName(QStringLiteral("lineEditIP"));
        lineEditIP->setGeometry(QRect(200, 20, 231, 41));
        lineEditPort = new QLineEdit(client);
        lineEditPort->setObjectName(QStringLiteral("lineEditPort"));
        lineEditPort->setGeometry(QRect(200, 80, 231, 41));
        textEditRead = new QTextEdit(client);
        textEditRead->setObjectName(QStringLiteral("textEditRead"));
        textEditRead->setGeometry(QRect(190, 160, 421, 87));
        label_3 = new QLabel(client);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(90, 160, 72, 81));
        textEditWrite = new QTextEdit(client);
        textEditWrite->setObjectName(QStringLiteral("textEditWrite"));
        textEditWrite->setGeometry(QRect(190, 280, 421, 87));
        label_4 = new QLabel(client);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(90, 310, 72, 15));
        buttonsend = new QPushButton(client);
        buttonsend->setObjectName(QStringLiteral("buttonsend"));
        buttonsend->setGeometry(QRect(160, 420, 93, 28));
        buttonclose = new QPushButton(client);
        buttonclose->setObjectName(QStringLiteral("buttonclose"));
        buttonclose->setGeometry(QRect(430, 420, 93, 28));
        buttonconnect = new QPushButton(client);
        buttonconnect->setObjectName(QStringLiteral("buttonconnect"));
        buttonconnect->setGeometry(QRect(510, 70, 93, 28));

        retranslateUi(client);

        QMetaObject::connectSlotsByName(client);
    } // setupUi

    void retranslateUi(QWidget *client)
    {
        client->setWindowTitle(QApplication::translate("client", "Form", Q_NULLPTR));
        label->setText(QApplication::translate("client", "\346\234\215\345\212\241\345\231\250IP\345\234\260\345\235\200", Q_NULLPTR));
        label_2->setText(QApplication::translate("client", "\347\253\257\345\217\243\345\217\267", Q_NULLPTR));
        label_3->setText(QApplication::translate("client", "\346\216\245\345\217\227\346\241\206", Q_NULLPTR));
        label_4->setText(QApplication::translate("client", "\345\217\221\351\200\201\346\241\206", Q_NULLPTR));
        buttonsend->setText(QApplication::translate("client", "\345\217\221\351\200\201", Q_NULLPTR));
        buttonclose->setText(QApplication::translate("client", "\345\205\263\351\227\255", Q_NULLPTR));
        buttonconnect->setText(QApplication::translate("client", "\350\277\236\346\216\245", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class client: public Ui_client {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CLIENT_H
